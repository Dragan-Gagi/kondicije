var number= [15, -2, 22, 0, 13]

console.log ("The largest number of this five numbers is " +  number [2])

var a= {
	numberOne : 3 ,
	numberTwo:-7 ,
	numberThree: 2
};



if( a.numberOne === a.numberTwo ) {
	console.log ("first number is equal to the second number")

}

else if (a.numberTwo===a.numberTwo) {

console.log ("The second number haves a sign (-)")
}

else {

	console.log ( "third number is larger than the first number")

}

var world= "Hallo Welt"


switch (world) {
	case "????? ??" :
	console.log ("This is Korean");
	break;
	case "Ahoj svet":
	console.log( "This is Slovakian");
	break;
	 case "Merhaba d�nya" :  
	console.log ( "This is Turkish");
	break;
	case "Hallo Welt":
	console.log ("This is German");
	break;
	case "Hello World":
	console.log("This is English");

}


var userAge=
		age= 29;

var checkUser=
		age=28;


userAge>checkUser ? console.log (userAge) : console.log (checkUSer);

if(userAge !==checkUser) {
	console.log("User is less than 28 years old")
};

if(checkUser>userAge){

	console.log("User is older than 28")
}

else if (checkUser<userAge) {
	console.log("User is 28")
}

 
